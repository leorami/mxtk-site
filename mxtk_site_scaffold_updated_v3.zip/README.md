# MXTK Site Scaffold (Updated v3)
- Light default; Dark toggle (persisted).
- Transparency hub: proofs (IPFS), oracle log, ops cost estimator, OTC aggregates, addresses, risk.
- Institutions page: Persona (KYC) and BitGo (escrow) placeholders.
- Replace placeholder data in `lib/placeholders.ts`.
## Dev
pnpm install && pnpm dev
